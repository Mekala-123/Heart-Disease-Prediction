"""
BlinkChart Dataset Generator (minimal)
Usage:
  python dataset_generator.py --out ./out --seed 42
"""
import argparse, os, csv, math, datetime as dt, numpy as np

def save_csv(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerows(rows)

def sales_by_region(out, months=18, seed=42):
    rng = np.random.default_rng(seed)
    rows = [["Month","Region","SalesUSD"]]
    regions = ["North","South","East","West"]
    start = dt.date(2024,1,1)
    for m in range(months):
        month = (start + dt.timedelta(days=int(m*30.5))).strftime("%Y-%m")
        for r in regions:
            base = {"North":12000,"South":10000,"East":14000,"West":11000}[r]
            season = 1 + 0.15*math.sin(m/12*2*math.pi)
            val = int(base*season + rng.normal(0,1200))
            rows.append([month, r, max(val, 1000)])
    save_csv(os.path.join(out, "SMB", "sales_by_region_monthly.csv"), rows)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="./out")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    sales_by_region(args.out, seed=args.seed)
    print("Generated datasets in", args.out)
